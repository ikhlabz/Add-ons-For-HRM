<?php

return [
    'name' => 'Manufacturing',
    'module_version' => '3.1',
    'pid' => 4,
];

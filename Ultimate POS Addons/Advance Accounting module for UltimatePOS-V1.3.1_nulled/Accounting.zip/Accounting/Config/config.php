<?php

return [
    'name' => 'Accounting',
    'module_version' => "1.3.1",
    'pid' => 1,
    'lic1' => 'aHR0cHM6Ly9sLnBubi5zb2x1dGlvbnMvYXBpL3R5cGVfMQ==',
];

$(function () {
    $('.tree').treegrid();
    $('.tree-2').treegrid({
        expanderExpandedClass: 'glyphicon glyphicon-minus',
        expanderCollapsedClass: 'glyphicon glyphicon-plus'
    });
});
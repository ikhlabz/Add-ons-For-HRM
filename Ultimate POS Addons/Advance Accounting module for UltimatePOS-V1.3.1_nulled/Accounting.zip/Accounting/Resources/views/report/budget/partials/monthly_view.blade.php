@component('accounting::components.tree_view_table', ['table_responsive' => true])
    @include('accounting::report.budget.partials.monthly_view_table')
@endcomponent

<div class="btn-group">
    <button href="#" data-toggle="dropdown" aria-expanded="false" class="btn btn-primary dropdown-toggle">
        {{ $label }}
        <span class="caret"></span><span class="sr-only"></span></button>
    <div class="dropdown-menu dropdown-menu-right">
        {{ $slot }}
    </div>
</div>
<section class="content-header no-print">
    <h1>
        {{ $title }}
        @if (!empty($subtitle))
            <small>{{ $subtitle }}</small>
        @endif
    </h1>
</section>

<?php

return [
    'spreadsheet' => 'Spreadsheet',
    'spreadsheet_module' => 'Modul Spreadsheet',
    'sheets' => 'Lembar',
    'my_spreadsheets' => 'Spreadsheet saya',
    'create_spreadsheet' => 'Buat Spreadsheet',
    'no_spreadsheet_found' => 'Tidak ada spreadsheet yang ditemukan!',
    'view_spreadsheet' => 'Lihat Spreadsheet',
    'share' => 'Membagikan',
    'share_excel' => 'Bagikan spreadsheet',
    'todos' => 'Todo',
    'access_spreadsheet' => 'Akses spreadsheet',
    'create_spreadsheet' => 'Buat spreadsheet',
    'spreadsheet_shared_notif_text' => ':shared_by membagikan spreadsheet - :name',
    'shared_by' => 'Dibagikan oleh : :nama',
    'created_by' => 'Dibuat oleh : :nama',
];

<?php

return [
    'spreadsheet' => 'سپریډ شیټ',
    'spreadsheet_module' => 'د سپریډ شیټ ماډل',
    'sheets' => 'شیټونه',
    'my_spreadsheets' => 'زما سپریډ شیټونه',
    'create_spreadsheet' => 'سپریډ شیټ جوړ کړئ',
    'no_spreadsheet_found' => 'هیڅ سپریڈ شیټ ونه موندل شو!',
    'view_spreadsheet' => 'سپریډ شیټ وګورئ',
    'share' => 'شریکول',
    'share_excel' => 'سپریڈ شیټ شریک کړئ',
    'todos' => 'Todos',
    'access_spreadsheet' => 'سپریڈ شیټ ته لاسرسی',
    'create_spreadsheet' => 'سپریډ شیټ جوړ کړئ',
    'spreadsheet_shared_notif_text' => ':shared_by یو سپریڈ شیټ شریک کړ - :name',
    'shared_by' => 'له خوا شریک شوی : :name',
    'created_by' => 'لخوا جوړ شوی : :name',
];

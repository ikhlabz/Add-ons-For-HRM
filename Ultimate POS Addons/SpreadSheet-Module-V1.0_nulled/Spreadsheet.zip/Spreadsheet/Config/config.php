<?php

return [
    'name' => 'Spreadsheet',
    'module_version' => '1.0',
    'pid' => 13,
];

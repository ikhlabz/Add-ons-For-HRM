<?php

return [
    'name' => 'AssetManagement',
    'module_version' => '2.1',
    'pid' => 14,
];

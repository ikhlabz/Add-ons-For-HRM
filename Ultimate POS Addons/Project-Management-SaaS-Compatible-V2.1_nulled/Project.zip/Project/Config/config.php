<?php

return [
    'name' => 'Project',
    'module_version' => '2.1',
    'pid' => 5,
];

<?php

return [
    'name' => 'Woocommerce',
    'module_version' => '4.0',
];
